import React, { Component } from "react";
import { Link } from "react-router-dom";
import perfilIcono from "../img/perfil.png";

class ItemMenu extends Component {
  render() {
    const { contenido, rutaAtras } = this.props; // Contenido dinámico recibido por props

    return (
      <div>
        {/* Menú superior */}
        <nav className="menu-superior">
          <div className="menu-logo">APP_NAME</div>
          <div className="menu-links">
            <a href="#home">Home</a>
            <a href="#about">Sobre Nosotros</a>
            <a href="#contact">Contáctenos</a>
            <a href="#messages">Mensajes</a>
            <img src={perfilIcono} alt="Perfil" className="menu-perfil-icono" />
            <Link to="/inventario" className="btn-ir-inventario">
              Inventario
            </Link>
          </div>
        </nav>

        {/* Contenido principal */}
        <div className="contenido-principal">
          {contenido}

          {/* Botón Atrás */}
          <div className="boton-navegacion">
            {/* Enlace para la navegación hacia atrás */}
            <Link to={rutaAtras || "/"} className="boton-atras">
              Atrás
            </Link>
          </div>
        </div>

        {/* Pie de página */}
        <footer className="app-footer">
          <div className="footer-item">
            <img
              src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fcdn-icons-png.flaticon.com%2F512%2F710%2F710078.png&f=1&nofb=1"
              alt="Alta Calidad"
            />
            <span>Alta Calidad</span>
          </div>
          <div className="footer-item">
            <img
              src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fclipground.com%2Fimages%2Fgarantia-png-6.png&f=1&nofb=1"
              alt="Garantía de Protección"
            />
            <span>Garantía de Protección</span>
          </div>
          <div className="footer-item">
            <img
              src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fpng.pngtree.com%2Fpng-clipart%2F20230427%2Foriginal%2Fpngtree-shipping-line-icon-png-image_9117422.png&f=1&nofb=1"
              alt="Envío Gratis"
            />
            <span>Envío Gratis<br />Orden mayor a $100</span>
          </div>
          <div className="footer-item">
            <img
              src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fcdn-icons-png.flaticon.com%2F512%2F2618%2F2618521.png&f=1&nofb=1"
              alt="24 / 7 Soporte"
            />
            <span>24 / 7 Soporte</span>
          </div>
        </footer>
      </div>
    );
  }
}

export default ItemMenu;
